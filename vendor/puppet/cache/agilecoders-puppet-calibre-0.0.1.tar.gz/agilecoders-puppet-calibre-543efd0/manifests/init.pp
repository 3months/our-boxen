# Public: Install Calibre.app to /Applications.
#
# Examples
#
#   include calibre
class calibre {
  package { 'Calibre':
    source   => 'http://sourceforge.net/projects/calibre/files/0.9.27/calibre-0.9.27.dmg',
    provider => 'appdmg'
  }
}
